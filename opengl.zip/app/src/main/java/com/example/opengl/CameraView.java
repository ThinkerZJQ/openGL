package com.example.opengl;


import androidx.camera.core.CameraX;
import androidx.camera.core.Preview;
import androidx.camera.core.PreviewConfig;
import androidx.lifecycle.LifecycleOwner;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Size;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;


public class CameraView extends GLSurfaceView implements GLSurfaceView.Renderer{

// 世界坐标系 摄像头 二维
    private SurfaceTexture cameraSurfaceTexture;
    private int textures = 0;
    private ScreenFilter screenFilter;
    // int gpu地址
    public CameraView(Context context) {
        super(context);
    }

    public CameraView(Context context, AttributeSet attrs) {
        super(context, attrs);
        // 设置surfaceview监听
        setEGLContextClientVersion(2);// 设置版本，2或者3，2更成熟点
        setRenderer(this);
        setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);// 手动渲染
        initCameraX();
    }

    // 这段代码运行在cpu还是gpu？（cpu）
    private void initCameraX() {
        PreviewConfig.Builder builder = new PreviewConfig.Builder();
        builder.setTargetResolution(new Size(640, 480));
        builder.setLensFacing(CameraX.LensFacing.FRONT);
        PreviewConfig previewConfig = builder.build();
        Preview preview = new Preview(previewConfig);
        CameraX.bindToLifecycle((LifecycleOwner)getContext(),preview);
        preview.setOnPreviewOutputUpdateListener(new Preview.OnPreviewOutputUpdateListener(){
            @Override
            public void onUpdated(Preview.PreviewOutput output){
                cameraSurfaceTexture = output.getSurfaceTexture();

            }
        });

    }

    @Override public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        // 拿到摄像头在gpu的地址
        cameraSurfaceTexture.attachToGLContext(textures);
        // 监听摄像头的刷新
        cameraSurfaceTexture.setOnFrameAvailableListener(new SurfaceTexture.OnFrameAvailableListener(){
            @Override public void onFrameAvailable(SurfaceTexture surfaceTexture) {
                Log.e("testTag","摄像头触发");
                requestRender();
            }
        });
    screenFilter = new ScreenFilter(getContext());
    }

    @Override public void onSurfaceChanged(GL10 gl, int width, int height) {


    }

    @Override public void onDrawFrame(GL10 gl) {
        Log.e("testTag","触发成功");
        // 数据更新到gpu中
        cameraSurfaceTexture.updateTexImage();
        float[] mtx = new float[16];
        cameraSurfaceTexture.getTransformMatrix(mtx);
        // 矩阵变换,摄像头大小变换为屏幕大小
        screenFilter.onDraw(getWidth(),getHeight(),mtx,textures);
    }
}

package com.example.opengl;

import android.content.Context;
import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class ScreenFilter {
    // 加载opengl程序

    int program;
    FloatBuffer vPositionFloatBuffer;
    float[] vPositionVERTEX={
            -1.0f,-1.0f,
            1.0f,-1.0f,
            -1.0f,1.0f,
            1.0f,1.0f
    };
    float[] TEXTURE = {
            0.0f,0.0f,
            1.0f,0.0f,
            0.0f,1.0f,
            1.0f,1.0f
    };
    FloatBuffer vCoordFloatBuffer;
    int vPosition;
    private int vMatrix;

    int vCoord;
    int vTexture;

    public ScreenFilter(Context context) {
        // ##################顶点程序############################
        // opengl程序需要编译吗？（需要，但是运行中去编译）
        String vertexSharder = FileUtils.readRawTextFile(context, R.raw.camera_vert);
        int vShader = GLES20.glCreateShader(GLES20.GL_VERTEX_SHADER);
        // 绑定源码，这是面向对象还是面向过程的代码？（面向过程）
        GLES20.glShaderSource(vShader, vertexSharder);
        // 编译
        GLES20.glCompileShader(vShader);
        // ##################着色程序############################
        String fragSharder = FileUtils.readRawTextFile(context, R.raw.camera_frag);
        int fShader = GLES20.glCreateShader(GLES20.GL_FRAGMENT_SHADER);
        GLES20.glShaderSource(fShader, fragSharder);
        // 编译配置
        GLES20.glCompileShader(fShader);
        // ##################总程序############################
        program = GLES20.glCreateProgram();
        GLES20.glAttachShader(program, vShader);
        GLES20.glAttachShader(program, fShader);
        GLES20.glLinkProgram(program);
        // ##################坐标系############################
        // 什么是世界坐标系？什么是纹理坐标系？
        // cpu -----》 gpu
        vPositionFloatBuffer = ByteBuffer.allocateDirect(4 * 4 * 2).order(ByteOrder.nativeOrder()).asFloatBuffer();
        vPositionFloatBuffer.clear();
        vPositionFloatBuffer.put(vPositionVERTEX);
        vPosition = GLES20.glGetAttribLocation(program, "vPosition");

        vCoordFloatBuffer = ByteBuffer.allocateDirect(4 * 4 * 2).order(ByteOrder.nativeOrder()).asFloatBuffer();
        vCoordFloatBuffer.clear();
        vCoordFloatBuffer.put(TEXTURE);
        //接收纹理坐标
        vCoord = GLES20.glGetAttribLocation(program, "vCoord");

        vTexture= GLES20.glGetUniformLocation(program,"VTexture");
        // 变换矩阵
        vMatrix = GLES20.glGetUniformLocation(program,"vMatrix");
    }


    // 渲染opengl程序
    public void onDraw(int mWdith, int mHeight, float[] mtx, int texture) {
        GLES20.glViewport(0, 0, mWdith, mHeight);
        GLES20.glUseProgram(program);
        // 告诉gpu读取位是从0开始的
        vPositionFloatBuffer.position(0);
        vCoordFloatBuffer.position(0);
        // cpu的值，赋值给gpu
        GLES20.glVertexAttribPointer(vPosition, 2, GLES20.GL_FLOAT, false, 0, vPositionFloatBuffer);
        // 开启变量
        GLES20.glEnableVertexAttribArray(vPosition);
        //########################纹理########################
        GLES20.glVertexAttribPointer(vCoord, 2, GLES20.GL_FLOAT, false, 0, vCoordFloatBuffer);
        GLES20.glEnableVertexAttribArray(vCoord);
        // ########################创建采样器########################
        GLES20.glActiveTexture(GLES20.GL_TEXTURE);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D,texture);
        GLES20.glUniform1i(vTexture,0);
        GLES20.glUniformMatrix4fv(vMatrix,1,false,mtx,0);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4);
    }
}

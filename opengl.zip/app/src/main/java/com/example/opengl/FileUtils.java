package com.example.opengl;

import android.content.Context;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class FileUtils {
    public static String readRawTextFile(Context context, int rawId){
        InputStream is = context.getResources().openRawResource(rawId);
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        String line;
        StringBuilder sb = new StringBuilder();
        try{
            while((line = br.readLine())!=null){
                sb.append(line);
                sb.append("\n");
            }
        }catch(Exception e){
            // ignore
        }
        try{
            br.close();
        }catch(IOException e){}
        return sb.toString();
    }
}
